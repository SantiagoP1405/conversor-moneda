package com.santiagogomez.aluracursos.challenge_javapoo.base;
import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class Currency {
    //Atributos
    @SerializedName("base_code")
    public String base_code;
    @SerializedName("conversion_rates")
    public Map<String, Double> conversion_rates;

    //Métodos
    public Map<String, Double> getConversion_rates() {
        return conversion_rates;
    }

    @Override
    public String toString() {
        return "Currency{" +
                "baseCode='" + base_code +
                ", conversionRates=" + conversion_rates +
                '}';
    }

}
