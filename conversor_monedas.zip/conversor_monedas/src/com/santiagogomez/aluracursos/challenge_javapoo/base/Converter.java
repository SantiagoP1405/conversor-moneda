package com.santiagogomez.aluracursos.challenge_javapoo.base;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class Converter {
    Scanner input = new Scanner(System.in);
    //Atributos
    private String api = "0c5145b94c851622eef31958";
    private Gson gson;

    //Métodos
    public Converter() {
        this.gson = new GsonBuilder()
                .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
                .setPrettyPrinting()
                .create();
    }

    public Currency getConversions(String baseCurrency){
        String url = "https://v6.exchangerate-api.com/v6/" + api + "/latest/" + baseCurrency;
        try{
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();
            HttpResponse<String> response = client
                    .send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();
            Currency miCurrency = gson.fromJson(json, Currency.class);
            return miCurrency;
        }
        catch (IOException | InterruptedException e) {
            System.out.println(e.getMessage());
        }
        catch (Exception e){
            System.out.println(e);
        }
        return null;
    }

    public void convertCurrency(String currency, String clave){
        Converter converter = new Converter();
        System.out.println("Ingresa el valor que deseas convertir (en " + currency + "): ");
        Currency miCurrency = converter.getConversions(currency);
        double cantidad = input.nextDouble();
        double resultado = cantidad * miCurrency.getConversion_rates().get(clave);
        System.out.println(String.format("%.2f %s corresponden a %.2f %s", cantidad, currency, resultado, clave));
    }
}
