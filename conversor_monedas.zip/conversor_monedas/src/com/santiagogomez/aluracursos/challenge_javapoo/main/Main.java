/*
Santiago Patricio Gómez Ochoa
Creado para los cursos de Alura Latam y Oracle
Programa ONE

Desafío "Conversor de moneda"
*/

package com.santiagogomez.aluracursos.challenge_javapoo.main;
import com.santiagogomez.aluracursos.challenge_javapoo.base.Converter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        String option, currency, clave;
        Scanner input = new Scanner(System.in);
        System.out.println("------ BIENVENIDO AL CONVERSOR DE MONEDA ☻ ------");
        System.out.println();
        Converter converter = new Converter();
        do{
            System.out.println("---------------------- MENU ----------------------");
            System.out.println();
            System.out.println("1) Peso mexicano -→ Dólar");
            System.out.println("2) Dólar -→ Peso Mexicano");
            System.out.println("3) Peso mexicano -→ Euro");
            System.out.println("4) Euro -→ Peso mexicano");
            System.out.println("5) Peso mexicano -→ Peso Argentino");
            System.out.println("6) Peso argentino -→ Peso Mexicano");
            System.out.println("7) Dólar -→ Euro");
            System.out.println("8) Euro -→ Dólar");
            System.out.println("0) Salir");
            System.out.println();
            System.out.println("Elige una opción válida: ");
            option = input.next();
            switch (option){
                case "1":
                    currency = "MXN";
                    clave = "USD";
                    converter.convertCurrency(currency, clave);
                    break;
                case "2":
                    currency = "USD";
                    clave = "MXN";
                    converter.convertCurrency(currency, clave);
                    break;
                case "3":
                    currency = "MXN";
                    clave = "EUR";
                    converter.convertCurrency(currency, clave);
                    break;
                case "4":
                    currency = "EUR";
                    clave = "MXN";
                    converter.convertCurrency(currency, clave);
                    break;
                case "5":
                    currency = "MXN";
                    clave = "ARS";
                    converter.convertCurrency(currency, clave);
                    break;
                case "6":
                    currency = "ARS";
                    clave = "MXN";
                    converter.convertCurrency(currency, clave);
                    break;
                case "7":
                    currency = "USD";
                    clave = "EUR";
                    converter.convertCurrency(currency, clave);
                    break;
                case "8":
                    currency = "EUR";
                    clave = "USD";
                    converter.convertCurrency(currency, clave);
                    break;
                case "0":
                    System.out.println("Fin del programa");
                    System.out.println("--------------------------------------------------");
                    break;
                default:
                    System.out.println("ERROR - Opción no válida");
                    break;
            }
            System.out.println();
        }while (!option.equals("0"));
        input.close();
    }
}